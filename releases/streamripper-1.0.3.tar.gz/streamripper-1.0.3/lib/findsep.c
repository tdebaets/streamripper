#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#if WIN32
#include <windows.h>
#include "decoder.h"
#include "memory_input.h"
#include "audio_output.h"
#else
#include "interface.h"
#endif
#include "mpeg.h"
#include "findsep.h"
#include "util.h"
#include "types.h"
#include "cbuffer.h"


#define MP3_BUFFER_SIZE			(1024*10)
#define REALLOC_CHUNKS			(0xFF)
#define MIN_GOOD_FRAMES			3
#define RMS_WINDOWS				1000
#define MIN_SILENT_RMS			500
#define MIN_SILENT_RMS_FRAMES	50


/*********************************************************************************
 * Public functions
 *********************************************************************************/
error_code	findsep_silence(const u_char *buffer, const u_long size, u_long *pos);

/*********************************************************************************
 * Private functions
 *********************************************************************************/
static error_code	decode_buffer(const u_char *buffer, long size, short **pcm_buffer, u_long *pcmsize);
static u_long		find_silence(const short *buffer, const u_long size, const int numwindows);
static void			convert_to_mono(short *pcmdata, u_long size, u_long *newsize);


/*********************************************************************************
 * Private Vars
 *********************************************************************************/
typedef struct RMSst
{
	u_long pos;
	double val;
} RMS;

error_code findsep_silence(const u_char *buffer, const u_long size, u_long *pos)
{
	short *pcm_buffer = NULL;
	u_long pcmsize, monosize;
	u_long mypos = 0, pcmpos = 0;
	int offset = 0;
	float ratio = 0;
	int ret;

	if (mpeg_find_first_header(buffer, size, 3, &offset) != SR_SUCCESS)
	{
		*pos = 0;
		return SR_ERROR_CANT_DECODE_MP3; // Not really, but what else can we do?
	}

	debug_printf("\nstart decode\n");
	if ((ret = decode_buffer(buffer+offset, size-offset, &pcm_buffer, &pcmsize)) != SR_SUCCESS)
	{
		*pos = offset; // better then nothing.
		return ret; 
	}
	debug_printf("end decode\n");

	// Convert to mono
	convert_to_mono(pcm_buffer, pcmsize, &monosize);
	pcmsize = monosize;

	ratio = (float)size / pcmsize;

	// Find the lowest RMS 
	pcmpos = find_silence(pcm_buffer, pcmsize, RMS_WINDOWS);

	// mypos is an aprox silent position based of the PCM data
	mypos = (u_long)(((float)pcmpos)*ratio);
	
	// Find the first valid MPEG header
	offset = 0;
	mpeg_find_first_header(buffer+mypos, size-mypos, MIN_GOOD_FRAMES, &offset);
	*pos = mypos + offset;

	// Just to make sure nothing stupid happened
	if (*pos > size)
		*pos = size;

	free(pcm_buffer);

	return SR_SUCCESS;
	
}

void convert_to_mono(short *pcmdata, u_long size, u_long *newsize)
{
	u_long i, y, nsize;
	short *mono = malloc((size/2) * sizeof(short));

	for(i = 1, y = 0; i < size; i += 2, y++)
	{
		mono[y] = (pcmdata[i-1] + pcmdata[i]) / 2;

	}
	nsize = size/2;
	memset(pcmdata, 0, size * sizeof(short));
	memcpy(pcmdata, mono, nsize * sizeof(short));
	*newsize = nsize;

	free(mono);
}

u_long find_silence(const short *buffer, const u_long size, const int numwindows)
{

	const int window_size = size / numwindows;
	int rms_vals_count; 
	RMS *rms_vals;
	u_long x, pos;
	int i, n;
	int min;	
	
	if (window_size == 0)
		return 0;

	rms_vals_count = size / window_size;
	rms_vals = calloc(rms_vals_count, sizeof(RMS));

	x = 0;

	// Get RMS values
	for(i = 0; i < rms_vals_count; i++)
	{
		n = window_size;
		while(n--)
		{
			rms_vals[i].val += pow(buffer[x++], 2);
		}
		rms_vals[i].val = sqrt(rms_vals[i].val / window_size);
		rms_vals[i].pos = x - (window_size/2);
	}

	for(i = 0, min = 0; i < rms_vals_count; i++)
	{
		if (rms_vals[i].val < rms_vals[min].val)
			min = i;
	}

	// Get the lowest value within the winning window
	pos = rms_vals[min].pos;
	min = pos;	// Min is now an index of buffer, not rms_vals
	for(i = pos; i < (signed)pos+window_size; i++)
	{
		if (buffer[i] < buffer[min])
			min = i;
	}
	pos = min;


	free(rms_vals);
//	debug_printf("\npcmpos: %ld\n", pos);
	return pos;
}

/*
 * I'm sick of trying to make mpglib work correctly. so i'm going back to using xaudio
 * for the win32 build. everything else will still use mpglib.
 */
#if WIN32
// Note: size must be larger then MP3_BUFFER_SIZE
error_code decode_buffer(const u_char *buffer, long size, short **pcm_buffer, u_long *pcmsize)
{
    int		status; 
    u_long	bufferpos = 0;
    u_char	*pcm, *my_pcm_buf;
    u_long	pcm_size = 0;
    int		mp3buffersize = MP3_BUFFER_SIZE;
    int		pcm_chunk_size = 0;
    u_long	pcm_real_size;
	int		ret;
	XA_InputModule	module;
	XA_DecoderInfo	*decoder = NULL;
   
	// Init xaudio
	if (mp3buffersize > size)
		return SR_ERROR_CANT_DECODE_MP3;

	if (decoder_new(&decoder) != XA_SUCCESS)
		return SR_ERROR_CANT_INIT_XAUDIO;

	memory_input_module_register(&module);
	decoder_input_module_register(decoder, &module);

	ret = decoder_input_new(decoder, NULL, XA_DECODER_INPUT_AUTOSELECT);
    if (ret != XA_SUCCESS)
    {
            decoder_delete(decoder);
            return SR_ERROR_CANT_INIT_XAUDIO;
    }

    if (decoder_input_open(decoder) != XA_SUCCESS)
    {
            decoder_delete(decoder);
            return SR_ERROR_CANT_INIT_XAUDIO;
    }
    memory_input_flush(decoder->input->device);


	// Decode mp3
    do 
    {

		if (bufferpos == (unsigned)size)
			break;

		if (bufferpos > (unsigned)(size-MP3_BUFFER_SIZE))
			mp3buffersize = size - bufferpos;

		memory_input_feed(decoder->input->device, &buffer[bufferpos], mp3buffersize);

		do {
		status = decoder_decode(decoder, NULL);
		if (status == XA_SUCCESS) 
		{
			if (!pcm_chunk_size)
			{
				pcm_chunk_size = decoder->output_buffer->size;
				pcm_real_size = REALLOC_CHUNKS*pcm_chunk_size;
				my_pcm_buf = malloc(pcm_real_size);
			}

			pcm = (u_char *)decoder->output_buffer->pcm_samples;
			if (*pcm)                //forget until we start getting none null frames
			{
				pcm_size += pcm_chunk_size;
				if (pcm_size % pcm_real_size == 0)
				{
					pcm_real_size += (REALLOC_CHUNKS*pcm_chunk_size);
					my_pcm_buf = realloc(my_pcm_buf, pcm_real_size);
				}
				memcpy((my_pcm_buf)+(pcm_size-pcm_chunk_size), pcm, pcm_chunk_size);
			}
                    }
        } while(status == XA_SUCCESS ||
                        status == XA_ERROR_INVALID_FRAME);
        bufferpos += mp3buffersize;

    } while(status == XA_SUCCESS ||
                status == XA_ERROR_TIMEOUT);


    if (decoder_input_close(decoder) != XA_SUCCESS)
    {
        decoder_delete(decoder);
        return SR_ERROR_CANT_INIT_XAUDIO;
    }

    decoder_delete(decoder);

    *pcm_buffer = (short *)my_pcm_buf;
    *pcmsize = pcm_size / 2;
    return SR_SUCCESS;
}
#else
// mpglib (barf!) version of decode_buffer.
error_code decode_buffer(const u_char *buffer, long size, short **pcm_buffer, u_long *pcmsize)
{
    int decode_status;
    u_long pcm_max_size = size*50;  // Better not ever get better then 100x compression
    int decoded_size;
    BOOL pcm_started = FALSE;
    char *pcmbuf = (char *)malloc(pcm_max_size);
    MPSTR mp;
    *pcmsize = 0;
    InitMP3(&mp);
    memset(pcmbuf, 0, pcm_max_size);
    // Load up the mp3 data into the decoder
    decode_status = decodeMP3(&mp, (char*)buffer, size, pcmbuf, pcm_max_size, &decoded_size);
	if (decode_status == MP3_VERY_BAD_ERR)
	{
		free(pcmbuf);
		return SR_ERROR_CANT_DECODE_MP3;
	}
    do
    {
            // Don't record until we start getting some PCM data
            //printf("decode_status = %d, decoded_size = %d\n", decode_status, decoded_size);
            if (pcm_started)
                    *pcmsize += decoded_size;
            else if (*pcmbuf)
                    pcm_started = TRUE;

            // and roll it out into out buffer
            decode_status = decodeMP3(&mp, NULL, 0, pcmbuf+*pcmsize, pcm_max_size-*pcmsize, &decoded_size);
			if (decode_status == MP3_ERR)
				debug_printf("Got MP3_ERR!!\n");
			else if(decode_status == MP3_VERY_BAD_ERR)
				break;

            if (*pcmsize > pcm_max_size)
            {
                    free(pcmbuf);
                    return SR_ERROR_PCM_BUFFER_TO_SMALL;
            }
    } while(mp.bsize && decode_status != MP3_NEED_MORE);

    ExitMP3(&mp);

	// Seen this happen on 192kbit streams
	if (*pcmsize == 0)
	{
		free(pcmbuf);
		return SR_ERROR_CANT_DECODE_MP3;
	}
    *pcm_buffer = (short*)realloc((void *)pcmbuf, (size_t)*pcmsize);
    if (*pcm_buffer == NULL && *pcmsize != 0)
            return SR_ERROR_CANT_ALLOC_MEMORY;
    *pcmsize /= 2;  // Convert back to short

    return SR_SUCCESS;
}

#endif
