#ifndef __FINDSEP_H__
#define __FINDSEP_H__

#include "types.h"

extern error_code	findsep_silence(const u_char *buffer, const u_long size, u_long *pos);

#endif //__FINDSEP_H__
