/* ripstream.c - jonclegg@yahoo.com
 * buffer stream data, when a track changes decodes the audio and finds a silent point to
 * splite the track
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "cbuffer.h"
#include "findsep.h"
#include "util.h"
#include "ripstream.h"

/*********************************************************************************
 * Public functions
 *********************************************************************************/
error_code	ripstream_init(u_long buffersize_mult, IO_GET_STREAM *in, IO_PUT_STREAM *out, char *no_meta_name);
error_code	ripstream_rip();
void		ripstream_destroy();

/*********************************************************************************
 * Private functions
 *********************************************************************************/
static error_code	find_sep(u_long *pos);
static error_code end_track(u_long pos, char *trackname);
static error_code start_track(char *trackname);


/*********************************************************************************
 * Private Vars
 *********************************************************************************/
static CBUFFER			m_cbuffer;
static IO_GET_STREAM	*m_in;
static IO_PUT_STREAM	*m_out;
static char				m_last_track[MAX_TRACK_LEN] = {'\0'};
static char				m_current_track[MAX_TRACK_LEN] = {'\0'};
static char				m_no_meta_name[MAX_TRACK_LEN] = {'\0'};
static int				m_buffersize_mult;
static char				*m_getbuffer = NULL;
static int				m_find_silence = -1;
static BOOL				m_on_first_track = TRUE;

error_code ripstream_init(u_long buffersize_mult, IO_GET_STREAM *in, IO_PUT_STREAM *out, char *no_meta_name)
{

	if (!in || !out || buffersize_mult < 1 || !no_meta_name)
		return SR_ERROR_INVALID_PARAM;

	m_in = in;
	m_out = out;
	m_buffersize_mult = buffersize_mult;
	m_on_first_track = TRUE;
	strcpy(m_no_meta_name, no_meta_name);

	if ((m_getbuffer = malloc(in->getsize)) == NULL)
		return SR_ERROR_CANT_ALLOC_MEMORY;

	return cbuffer_init(&m_cbuffer, in->getsize * buffersize_mult);
	
}

void ripstream_destroy()
{
	if (m_getbuffer) {free(m_getbuffer); m_getbuffer = NULL;}
	m_find_silence = 0;
	m_in = NULL;
	m_out = NULL;
	m_buffersize_mult = 0;
	cbuffer_destroy(&m_cbuffer);
	m_last_track[0] = '\0';
	m_current_track[0] = '\0';
}

BOOL is_buffer_full()
{
	return (cbuffer_get_free(&m_cbuffer) - m_in->getsize) < m_in->getsize;
}

BOOL is_track_changed()
{
	return strcmp(m_last_track, m_current_track) != 0 && *m_last_track;
}

BOOL is_no_meta_track()
{
	return strcmp(m_current_track, NO_TRACK_STR) == 0;
}

error_code ripstream_rip()
{
	int ret;
	int real_ret = SR_SUCCESS;
	u_long extract_size;

	// only copy over the last track name if 
	// we are not waiting to buffer for a silent point
	if (m_find_silence < 0)
		strcpy(m_last_track, m_current_track);
	if ((ret = m_in->get_data(m_getbuffer, m_current_track)) != SR_SUCCESS)
	{
		// If it is a single track recording, finish the track
		if (is_no_meta_track())
			if ((ret = end_track(cbuffer_get_used(&m_cbuffer), m_no_meta_name)) != SR_SUCCESS)
				return ret;
		return ret;
	}
	
	// if the current track matchs with the special no track info 
	// name we declair that we are no longer on the first track (or the last for that matter)
	// this is so end_track will actually call end.
	if (is_no_meta_track() &&
		m_on_first_track)
	{
		if ((ret = start_track(m_no_meta_name)) != SR_SUCCESS)
			return ret;
	} 
	// if this is the first time we have received a track name, then we
	// can start the track
	else if	(*m_current_track && *m_last_track == '\0')
	{
		// Done say set first track on, because the first track 
		// should not be ended. It will always be incomplete.
		if ((ret = m_out->start_track(m_current_track)) != SR_SUCCESS)
			return ret;
	}

	if ((ret = cbuffer_insert(&m_cbuffer, m_getbuffer, m_in->getsize)) != SR_SUCCESS)
		return ret;

	// The track changed, signal a findsep in a little while
	if (is_track_changed() &&
		is_buffer_full() &&
		m_find_silence < 0)
	{
		m_find_silence = (m_buffersize_mult/2);
	}													

	m_find_silence--;


	// If the buffer is not full, buffer more
	if (!is_buffer_full())
		return SR_SUCCESS_BUFFERING;

	// This means we had a track change a little while back and it's time
	// to find a silent point to seperate the track
	if (m_find_silence == 0)
	{
		u_long pos = 0;

		if ((ret = find_sep(&pos)) != SR_SUCCESS)
			real_ret = ret;

		if ((ret = end_track(pos, m_last_track)) != SR_SUCCESS)
			real_ret = ret;

		if ((ret = start_track(m_current_track)) != SR_SUCCESS)
			real_ret = ret;

		m_find_silence = -1;
	}		

	// Remove our buffer size from the buffer
	extract_size = m_in->getsize < cbuffer_get_used(&m_cbuffer) ? m_in->getsize : cbuffer_get_used(&m_cbuffer);
	if ((ret = cbuffer_extract(&m_cbuffer, m_getbuffer, extract_size)) != SR_SUCCESS)
		return ret;
	
	// And post that data to our caller
	if (*m_current_track)
		m_out->put_data(m_getbuffer, extract_size);

	return real_ret;

}


error_code find_sep(u_long *pos)
{
	int cbufsize = cbuffer_get_used(&m_cbuffer);
	u_char *buf = (u_char *)malloc(cbufsize);
	int ret;

	if (!pos)
		return SR_ERROR_INVALID_PARAM;

	if ((ret = cbuffer_peek(&m_cbuffer, buf, cbufsize)) != SR_SUCCESS)
	{
		free(buf);
		return ret;
	}

#if DEBUG
	{
	char str[50];
	FILE *fp;
	static int tracknum;
	sprintf(str, "debug_%03d.mp3", ++tracknum);
	fp = fopen(str, "wb");
	fwrite(buf, 1, cbufsize, fp);
	fclose(fp);
	}
#endif

	*pos = 0;
	ret = findsep_silence(buf, cbufsize, pos);
	if (ret != SR_SUCCESS && ret != SR_ERROR_CANT_DECODE_MP3)
		return ret;
	
	if (*pos > cbuffer_get_used(&m_cbuffer))
	{
		debug_printf("pos bigger then buffer!!!");
	}

	if (*pos == 0)
	{
		free(buf);
		return SR_ERROR_CANT_FIND_TRACK_SEPERATION;
	}
	free(buf);

	return SR_SUCCESS;
}

error_code end_track(u_long pos, char *trackname)
{
	int ret;
	u_char *buf = (u_char *)malloc(pos);


	// get out the part of the last track
	if ((ret = cbuffer_extract(&m_cbuffer, buf, pos)) != SR_SUCCESS)
		goto BAIL;

	// Write that out to the current file
	if ((ret = m_out->put_data(buf, pos)) != SR_SUCCESS)
		goto BAIL;

	if (!m_on_first_track)
		if ((ret = m_out->end_track(trackname)) != SR_SUCCESS)
			goto BAIL;

BAIL:
	free(buf);
	return ret;

}
error_code start_track(char *trackname)
{
	int ret;
	if ((ret = m_out->start_track(trackname)) != SR_SUCCESS)
		return ret;

	m_on_first_track = FALSE;

	return SR_SUCCESS;
}

