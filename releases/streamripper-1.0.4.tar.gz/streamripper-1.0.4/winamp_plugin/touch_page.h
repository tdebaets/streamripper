#ifndef __TOUCH_PAGE_H__
#define __TOUCH_PAGE_H__

extern void touch_page_listing(char *proxyurl, char *streamname, char *track, int bitrate);

#endif //__TOUCH_PAGE__
