//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script.rc
//
#define IDD_DIALOG                      101
#define IDD_ENABLE                      101
#define IDD_OPTIONS                     102
#define IDI_SR_ICON                     105
#define IDR_POPUP_MENU                  110
#define IDC_START                       1000
#define IDC_STATUS                      1001
#define IDC_EDIT_FILENAME               1002
#define IDC_STREAMNAME                  1003
#define IDC_BITRATE                     1004
#define IDC_SERVERTYPE                  1005
#define IDC_METAINTERVAL                1006
#define IDC_RELAY                       1007
#define IDC_STOP                        1008
#define IDC_ENABLE                      1008
#define IDC_OPTIONS                     1009
#define IDC_OK                          1202
#define IDC_CHECK                       1203
#define IDC_SEPERATE_DIRS               1203
#define IDC_OUTPUT_DIRECTORY            1204
#define IDC_BROWSE                      1205
#define IDC_CHECK2                      1206
#define IDC_RECONNECT                   1206
#define IDC_OVER_WRITE                  1207
#define IDC_CHECK3                      1208
#define IDC_URLCOMBO                    1208
#define IDC_MAKE_RELAY                  1208
#define IDC_RIP_URL                     1209
#define IDC_ADD_FINSHED_TRACKS_TO_PLAYLIST 1209
#define IDC_CANCEL                      1210
#define IDC_EDIT1                       1211
#define IDC_ALLOW_TOUCH                 1211
#define IDC_PROXY                       1212
#define ID_MENU_STARTRIPPING            40001
#define ID_MENU_STOPRIPPING             40003
#define ID_MENU_OPTIONS                 40004
#define ID_MENU_OPEN                    40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
