//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StreamRipper32.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SRIPPER_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_NOITEMS                     104
#define IDS_TRACKINFO                   105
#define IDS_BITRATE                     106
#define IDS_DESCRIPTON                  107
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     131
#define IDI_ICON1                       135
#define IDB_PLAY                        136
#define IDB_STOP                        137
#define IDB_GREEN                       140
#define IDD_BUFFER                      141
#define IDD_MIRRORSELECT                142
#define IDR_MENU1                       143
#define IDC_IP                          1000
#define IDC_URL                         1000
#define IDC_PORT                        1001
#define IDC_DESTINATION                 1002
#define IDC_RIPAWAY                     1003
#define IDC_GENRE                       1004
#define IDC_BROADCASTS                  1005
#define IDC_REFRESH                     1006
#define IDC_STOPRIPPING                 1007
#define IDC_BYTES                       1010
#define IDC_SONGTITLE                   1011
#define IDC_RIPPING                     1014
#define IDC_STREAMNAME_IN_OUTPUT        1015
#define IDC_PLAY_BUTTON                 1022
#define IDC_STOP_BUTTON                 1023
#define IDC_GREEN_BM                    1024
#define IDC_PROGRESS1                   1025
#define IDC_BUFFER                      1026
#define IDC_FOLDER                      1027
#define IDC_MAXBYTES                    1028
#define IDC_MIRRORS                     1030
#define ID_EXIT                         1031
#define IDC_LIST_CTRL                   1046
#define IDC_STREAMNAME                  1048
#define IDC_RELAYPORT                   1049
#define IDC_STATIC1                     1050
#define IDC_STATIC2                     1051
#define IDC_STATIC3                     1052
#define IDC_STATIC4                     1053
#define IDC_CONNECT_RELAY               1054
#define IDC_STATIC5                     1055
#define IDC_ADD_SEQ                     1056
#define IDC_ID3                         1057
#define IDC_OVERWRITE                   1058
#define IDM_CONTEXT_ABOUT               32771
#define ID_CONTEXT_STARTRIP             32772
#define ID_CONTEXT_STOPRIPPING          32773
#define IDM_CONTEXT_REFRESH             32774
#define IDM_CONTEXT_WINAMP_PLAY         32775
#define IDM_CONTEXT_WINAMP_STOP         32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
